



function getMessages() {
    return $.getJSON(messagesURL);
}
